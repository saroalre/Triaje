# Voilà Binder Example

Este repositorio contiene una aplicación Voilà basada en Jupyter Notebook.

## Enlace a Binder:

[![Abrir en Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/TU_USUARIO/TU_REPO/HEAD?urlpath=voila/render/notebook.ipynb)
